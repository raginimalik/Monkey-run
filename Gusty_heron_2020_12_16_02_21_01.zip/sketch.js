var Monkey, bg, stone

function setup() {
  createCanvas(400, 400);
  Monkey=createSprite(10,10,10,10);
}

function draw() {
  background(220);
  drawSprites();
}